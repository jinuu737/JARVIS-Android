# JARVIS Android project

This repository contains the Android application and its Python backend resources.

## Build an APK on GitHub (no Android Studio required)

1. Create a **new, empty** GitHub repository. A name such as `Jarvis-AI` is fine.
2. Download and extract this ZIP on your computer, or open the ZIP with a file manager that can extract it.
3. Upload the **contents inside** the extracted folder to the top level of the GitHub repository. Do not upload the ZIP as a single file and do not upload an extra parent folder. The repository root must show `app/`, `build.gradle`, `settings.gradle`, `gradle.properties`, and `.github/`.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. If GitHub asks, enable Actions for the repository.
6. Select **Build JARVIS APK** on the left. Press **Run workflow**, select `main`, then press the green **Run workflow** button. A push to `main` also starts a build automatically.
7. Wait for the run to finish with a green check. Open that run, scroll to **Artifacts**, and download `JARVIS-debug-APK`.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installation from the browser or file manager you used.

## Important build detail

This project ZIP intentionally does not require a checked-in Gradle Wrapper. The GitHub Actions workflow installs Gradle 8.7 and runs `gradle assembleDebug` directly. This avoids the previous `gradlew: No such file or directory` failure when the project was uploaded without wrapper files.

## API key and signing

- Do not commit API keys, passwords, or `.env` files to a public repository.
- Configure the AI provider key inside the app's supported settings, if available. Do not paste a private key into this README or the workflow.
- The workflow creates a standard debug APK signed with the temporary Android debug key. It is for testing and installation, not a Play Store release.
- The original archive contained a keystore and a hardcoded signing password in Gradle. Those were removed from this cleaned ZIP. Debug builds use Android's normal debug signing instead.

## If the build fails

Open the failed job in Actions and expand the first red step. Share the complete error text or a screenshot of that step so the actual failure can be diagnosed.
