import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class Pickers(unittest.TestCase):
    def test_file_pickers_are_not_display_none(self):
        for base in ["app/src/main/python/app/ui/web", "windows/app/ui/web"]:
            js = (ROOT / base / "app.js").read_text(encoding="utf-8")
            html = (ROOT / base / "index.html").read_text(encoding="utf-8")
            css = (ROOT / base / "style.css").read_text(encoding="utf-8")
            self.assertNotIn("multiple: true, hidden: true", js, base)
            self.assertIn('id="fileInput" class="file-hidden"', html, base)
            self.assertIn(".file-hidden {", css, base)

    def test_songs_play_with_a_proper_audio_type(self):
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text(encoding="utf-8")
        self.assertIn("new Blob([rec.blob], { type: 'audio/mpeg' })", js)

    def test_no_silent_failure_without_a_playlist(self):
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text(encoding="utf-8")
        self.assertIn("Open a playlist first, then add songs.", js)


if __name__ == "__main__":
    unittest.main()


class Feedback(unittest.TestCase):
    def test_picker_reports_each_step(self):
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text(encoding="utf-8")
        self.assertIn("The file picker sent no songs back", js)
        self.assertIn("The photo picker sent nothing back", js)

    def test_visible_name_is_jarvis(self):
        html = (ROOT / "app/src/main/python/app/ui/web/index.html").read_text(encoding="utf-8")
        self.assertIn('id="brandName">JARVIS<', html)
        self.assertNotIn("LUNA ·", html)


class NativePicker(unittest.TestCase):
    def test_native_picker_is_wired_end_to_end(self):
        java = (ROOT / "app/src/main/java/com/luna/app/MainActivity.java").read_text(encoding="utf-8")
        for needle in ["PICK_REQUEST = 9", "public void pickFiles(final String kind)", "handlePicked(resultCode, data)",
                       "shouldInterceptRequest", "/__picked/", "shrinkPhoto(", "__lunaPicked"]:
            self.assertIn(needle, java, needle)
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text(encoding="utf-8")
        for needle in ["window.__lunaPicked = async", "LunaNative.pickFiles('songs')", "LunaNative.pickFiles('photos')",
                       "openSongPicker(l)", "fetch(s.url)"]:
            self.assertIn(needle, js, needle)
