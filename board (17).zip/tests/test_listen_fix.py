import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ListenFix(unittest.TestCase):
    def test_no_early_feed_close(self):
        src = (ROOT / "app/src/main/java/com/luna/app/ListenService.java").read_text(encoding="utf-8")
        self.assertIn("ear.attach(this, intent, null)", src)
        self.assertNotIn("ear.attach(this, intent, ep::fire)", src)

    def test_failures_are_spoken(self):
        src = (ROOT / "app/src/main/java/com/luna/app/ListenService.java").read_text(encoding="utf-8")
        self.assertIn("Sorry, I didn't catch that. Please say it again.", src)


if __name__ == "__main__":
    unittest.main()
