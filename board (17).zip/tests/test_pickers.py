import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class Pickers(unittest.TestCase):
    def test_file_pickers_are_not_display_none(self):
        for base in ["app/src/main/python/app/ui/web", "windows/app/ui/web"]:
            js = (ROOT / base / "app.js").read_text(encoding="utf-8")
            html = (ROOT / base / "index.html").read_text(encoding="utf-8")
            css = (ROOT / base / "style.css").read_text(encoding="utf-8")
            self.assertNotIn("multiple: true, hidden: true", js, base)
            self.assertIn('id="fileInput" class="file-hidden"', html, base)
            self.assertIn(".file-hidden {", css, base)

    def test_songs_play_with_a_proper_audio_type(self):
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text(encoding="utf-8")
        self.assertIn("new Blob([rec.blob], { type: 'audio/mpeg' })", js)

    def test_no_silent_failure_without_a_playlist(self):
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text(encoding="utf-8")
        self.assertIn("Open a playlist first, then add songs.", js)


if __name__ == "__main__":
    unittest.main()
