import sys
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))
from app.agent.fast import FastIntents  # noqa: E402


class Runner:
    platform = "android"

    def __init__(self):
        self.sent = []

    def execute(self, a, **k):
        self.sent.append(a)
        return {"action": a["action"], "label": "x", "status": "done" if a["action"] == "add_task" else "client", "text": "ok", "args": a}


class Phone:
    def __init__(self, on=True):
        self.on = on

    def messages_enabled(self):
        return self.on

    def contacts_enabled(self):
        return True

    def find_app(self, name):
        return ""

    def recent_messages(self, count, who=""):
        return []


class WatchTests(unittest.TestCase):
    def make(self, on=True):
        self.r = Runner()
        return FastIntents("android", Phone(on), self.r, now=lambda: datetime(2026, 11, 17, 14, 0).timestamp())

    def test_many_ways_to_ask(self):
        f = self.make()
        for said, who in [("tell me when Rahul messages me", "Rahul"), ("inform me when I receive a message from Rahul", "Rahul"),
                          ("inform me if I recieve a message from mom on whatsapp", "Mom"), ("let me know when priya texts", "Priya"),
                          ("notify me when I get a message from Rahul Sharma", "Rahul Sharma"), ("keep me posted about messages from dad", "Dad")]:
            self.r.sent.clear()
            self.assertTrue(f.match(said), said)
            self.assertEqual(self.r.sent[-1], {"action": "watch_person", "name": who}, said)

    def test_stop_and_not_hijacking_reading(self):
        f = self.make()
        f.match("stop watching rahul")
        self.assertEqual(self.r.sent[-1], {"action": "watch_person", "name": "Rahul", "stop": "yes"})
        self.r.sent.clear()
        for said in ("tell me the message from Rahul", "tell me what Rahul said"):
            f.match(said)
            self.assertFalse([a for a in self.r.sent if a["action"] == "watch_person"], said)

    def test_says_so_when_notification_access_is_off(self):
        out = self.make(on=False).match("tell me when Rahul messages me")
        self.assertIn("Notification access", out.text)

    def test_reminders(self):
        f = self.make()
        for said, title, when in [("remind me to call mom at 5 pm", "Call mom", "2026-11-17T17:00"), ("remind me in 10 minutes to drink water", "Drink water", "2026-11-17T14:10"),
                                  ("add reminder buy milk tomorrow at 8 am", "Buy milk", "2026-11-18T08:00"), ("remind me about the meeting at 3", "The meeting", "2026-11-17T15:00")]:
            self.r.sent.clear()
            self.assertIn("Reminder set", f.match(said).text, said)
            self.assertEqual((self.r.sent[-1]["title"], self.r.sent[-1]["when"]), (title, when), said)
        self.assertIn("When should I remind", f.match("remind me to pay rent").text)

    def test_no_song_downloads(self):
        out = FastIntents("android", Phone(), Runner()).match("download song moonlight sonata")
        self.assertIn("PLAYLISTS", out.text)
        self.assertNotIn("download_song", str(out.actions))


if __name__ == "__main__":
    unittest.main()
