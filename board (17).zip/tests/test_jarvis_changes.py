import sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app" / "src" / "main" / "python"))

from app.agent.fast import FastIntents  # noqa: E402


class Runner:
    def execute(self, action):
        return {"status": "client", "text": "ok", "args": action}


class Phone:
    def find_app(self, name): return ""
    def contacts_enabled(self): return True
    def messages_enabled(self): return False
    def find_contact(self, name): return []
    def recent_messages(self, limit=5, who=""): return []


def fast():
    return FastIntents("android", Phone(), Runner())


class MusicVoice(unittest.TestCase):
    def music(self, said):
        r = fast().match(said)
        self.assertIsNotNone(r, said)
        acts = [a for a in r.actions if a["status"] == "music"]
        self.assertTrue(acts, said)
        return acts[0]["args"]

    def test_play_a_named_playlist(self):
        self.assertEqual(self.music("play my study playlist"), {"op": "play", "name": "study"})
        self.assertEqual(self.music("Jarvis play my favourite songs"), {"op": "play", "name": "favourite"})
        self.assertEqual(self.music("play playlist road trip"), {"op": "play", "name": "road trip"})

    def test_controls(self):
        self.assertEqual(self.music("pause")["op"], "pause")
        self.assertEqual(self.music("next song")["op"], "next")
        self.assertEqual(self.music("previous track")["op"], "prev")
        self.assertEqual(self.music("stop the music")["op"], "stop")
        self.assertEqual(self.music("resume music")["op"], "play")

    def test_other_talk_is_not_music(self):
        for said in ["what time is it", "open youtube", "remind me to call mom"]:
            r = fast().match(said)
            self.assertFalse(r and any(a["status"] == "music" for a in r.actions), said)


class Installs(unittest.TestCase):
    def test_install_does_not_ask_first(self):
        src = (ROOT / "app/src/main/python/app/agent/actions.py").read_text(encoding="utf-8")
        self.assertIn('"install_app": ("android", False,', src)


class Photos(unittest.TestCase):
    def test_limits_allow_large_photos(self):
        src = (ROOT / "app/src/main/python/app/ui/server.py").read_text(encoding="utf-8")
        self.assertIn("len(data) > 16 * 1024 * 1024", src)
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text(encoding="utf-8")
        self.assertIn("createImageBitmap(file)", js)
        self.assertIn("const MAX_PHOTOS = 10;", js)


class Listening(unittest.TestCase):
    def test_gives_a_natural_pause_before_answering(self):
        src = (ROOT / "app/src/main/java/com/luna/app/Endpoint.java").read_text(encoding="utf-8")
        self.assertIn("QUIET_MS = 650", src)


class Name(unittest.TestCase):
    def test_no_luna_left_in_user_text(self):
        import re
        for f in list((ROOT / "app/src/main/python/app/ui/web").glob("*.html")) + list((ROOT / "app/src/main/python/app/ui/web").glob("*.js")):
            self.assertIsNone(re.search(r"(?<![\w-])Luna(?![\w])", f.read_text(encoding="utf-8")), f.name)


if __name__ == "__main__":
    unittest.main()
