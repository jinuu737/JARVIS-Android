@echo off
rem Starts Jarvis from this folder. Use Install-Jarvis.bat once to get a Desktop icon instead.
cd /d "%~dp0"
if exist "venv\Scripts\pythonw.exe" (
  start "" "venv\Scripts\pythonw.exe" main.py
) else (
  where pythonw >nul 2>&1 && ( start "" pythonw main.py ) || ( start "" python main.py )
)
